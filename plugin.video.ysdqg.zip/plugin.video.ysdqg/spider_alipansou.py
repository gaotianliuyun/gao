from spider import SpiderItemType, SpiderItem
from spider_aliyundrive import SpiderAliyunDrive
from bs4 import BeautifulSoup
from utils import get_image_path
import requests
import re
import xbmcaddon

_ADDON = xbmcaddon.Addon()

class SpiderAliPanSou(SpiderAliyunDrive):


    def name(self):
        return '猫狸盘搜'

    def is_searchable(self):
        return True

    def logo(self):
        return get_image_path('alipansou.png')

    def hide(self):
        return not _ADDON.getSettingBool('data_source_alipansou_switch')

    def list_categories(self):
        return []

    def list_items(self, parent_item=None, page=1):
        if parent_item is None:
            return [], False
        else:
            header = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36',
                 'Referer': 'https://www.alipansou.com' + '/s/' + parent_item['id']
            }
            if not parent_item['id'].startswith('http'):
                r = requests.get('https://www.alipansou.com' + '/cv/' + parent_item['id'], allow_redirects=False, headers=header)
                url = re.search(r'href=\"(.*)\"', r.text).group(1)
                parent_item['id'] = url
            return super().list_items(parent_item, page)

    def search(self, keyword):
        r = requests.get('https://www.alipansou.com/search',
                         params={
                             'k': keyword,
                             't': 7,
                         })
        soup = BeautifulSoup(r.text, 'html.parser')

        rows = soup.select('van-row > a')
        items = []
        for row in rows:
            remark = re.search(r'时间: (.*?) ', str(row.get_text)).group(1)
            name = self._remove_html_tags(row.find('template').__str__()).replace('\n','').replace('\t','').replace(' ','')
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    name='[{0}]/{1}'.format(remark, name),
                    id=re.search(r'/s/(.*)', row.get('href')).group(1),
                ))

        return items

    def _remove_html_tags(self, text):
        """Remove html tags from a string"""
        import re
        clean = re.compile('<.*?>')
        return re.sub(clean, '', text)

#if __name__ == '__main__':
    #spider = SpiderAliPanSou()
    #res = spider.search("脱口秀大会")
    #res = spider.resolve_play_url()
    #res = spider.list_items(parent_item={'type': 'directory', 'id': 'zdTl4sro943LrmyiFw8ETavtMwMEv', 'name': '[2021-11-04]/脱口秀大会', 'cover': '', 'description': '', 'cast': [], 'director': '', 'area': '', 'year': 0, 'sources': [], 'danmakus': [], 'subtitles': [], 'params': {}}, page=1)
    #print(res)