from spider import Spider, SpiderItemType, SpiderSource, SpiderItem, SpiderPlayURL
import requests
import re
from utils import get_image_path
from bs4 import BeautifulSoup
import xbmcaddon

_ADDON = xbmcaddon.Addon()

class SpiderKuaiBo(Spider):

    def name(self):
        return '快播'

    def logo(self):
        return get_image_path('kuaibo.png')

    def is_searchable(self):
        return True

    def hide(self):
        return not _ADDON.getSettingBool('data_source_kuaibo_switch')

    def list_items(self, parent_item=None, page=1):
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"}
        if parent_item is None:
            items = []
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='movie',
                    name='电影',
                    params={
                        'type': 'category',
                    },
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='serie',
                    name='剧集',
                    params={
                        'type': 'category',
                    },
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id="serie",
                    name='综艺',
                    params={
                        'type': 'category',
                    },
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id="anime",
                    name='动漫',
                    params={
                        'type': 'category',
                    },
                ))
            return items, False

        elif parent_item['params']['type'] == 'category':
            url = 'https://www.3qu.live/videos/{0}?page={1}'.format(parent_item['id'], page)
            r = requests.get(url=url, headers=header)
            soup = BeautifulSoup(r.text, 'html.parser')
            data = soup.select('div.item-content > a')
            items = []
            for video in data:
                vid = re.search(r'/videos/(.*?).html', video.get('href')).group(1)
                name = video.get('title')
                cover = 'https://www.3qu.live' + re.search(r"url\(\'(.*?)\'\)", video.get('style')).group(1)
                items.append(
                    SpiderItem(
                        type=SpiderItemType.Directory,
                        name=name,
                        id=vid,
                        cover=cover,
                        params={
                            'type': 'video',
                        },
                    ))
            if len(items) == 30:
                has_next_page = True
            else:
                has_next_page = False
            return items, has_next_page

        elif parent_item['params']['type'] == 'video':
            url = 'https://www.3qu.live/videos/{0}.html'.format(parent_item['id'])
            r = requests.get(url, headers=header)
            soup = BeautifulSoup(r.text, 'html.parser')
            cover = 'https://www.3qu.live' + re.search(r'src=\"(.*?)\"',str(soup.select('div.thumb-box > img')[0])).group(1)
            cast = ''
            description = ''
            area = ''
            year = ''
            director = ''
            infos = soup.select('div.info-box > ul')[0].get_text()
            if "演员:" in infos:
                cast = re.search(r"演员:(.*?):", infos).group(1).replace(' ', '')[:-2].split(',')
            if "简介:" in infos:
                description = re.search(r"简介:(.*)", infos).group(1)
            if "地区:" in infos:
                area = re.search(r"地区:(.*?) ", infos).group(1)
            if "年份:" in infos:
                year = re.search(r"年份:(.*?) ", infos).group(1)
            if "导演:" in infos:
                director = re.search(r"导演:(.*?) ", infos).group(1)
            urls = soup.select('div.playlist > a')
            items = []
            for url in urls:
                sources = []
                name = url.get_text()
                sources.append(
                    SpiderSource(
                        '快播影视',
                        {
                            'fid': parent_item['id'],
                            'sid': re.search(r'data-id=\"(.*?)\"', str(url)).group(1),
                        },
                    ))
                items.append(
                    SpiderItem(
                        type=SpiderItemType.File,
                        name=name,
                        cover=cover,
                        description=description,
                        cast=cast,
                        director=director,
                        area=area,
                        year=year,
                        sources=sources,
                    ))
            return items, False
        else:
            return [], False

    def resolve_play_url(self, source_params):
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"}
        url = 'https://www.3qu.live/api/v1/videos/{0}/{1}/playUrl'.format(source_params['fid'],source_params['sid'])
        r = requests.get(url, headers=header)
        data = r.json()['data']
        if data is None:
            return []
        apiurl = data['url']
        purl = 'https://www.3qu.live{0}'.format(apiurl)
        return SpiderPlayURL(purl)

    def search(self, keyword):
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"}
        url = 'https://www.3qu.live/api/v1/search?page=1&q={0}&type=all&period=0'.format(keyword)
        r = requests.get(url, headers=header)
        data = r.json()['data']['videos']
        items = []
        for video in data:
            sid = video['id']
            name = video['name']
            cover = 'https://www.3qu.live' + video['coverURL']
            description = video['summary']
            year = video['createdAt'][:4]
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    name=name,
                    id=sid,
                    cover=cover,
                    description=description,
                    cast='',
                    year=int(year),
                    params={
                        'type': 'video',
                    },
                ))
        return items

#if __name__ == '__main__':
    #spider = SpiderKuaiBo()
    #res = spider.list_items(parent_item={'type': 'directory', 'id': '636fe58cfc082949513f2667', 'name': '棺山古墓', 'cover': 'https://www.3qu.live/api/v1/static/img/835fe530003601c9e90d067b7b58c0fe2cc56c8d0619ef205ee4ffa7de8ac098eca5cd35868c6fba812265ad0e535d292dd660110b3ddd0278b4a9978341cfd1dd995eeed19ba52e5ec4bfb7c9564108b0133362c1c14d7b2850903daeb43a37.jpeg', 'description': '', 'cast': [], 'director': '', 'area': '', 'year': 0, 'sources': [], 'danmakus': [], 'subtitles': [], 'params': {'type': 'video'}}, page=1)
    #res = spider.resolve_play_url({'fid': '636fe58cfc082949513f2667', 'sid': '636fe58c6a7ad976c800bb9b'})
    #res = spider.search("同学两亿岁")
    #print(res)