from spider import Spider, SpiderItemType, SpiderSource, SpiderDanmaku, SpiderItem, SpiderPlayURL
from proxy import get_proxy_url
from urllib.parse import urlparse
from danmaku import get_danmaku_url
import requests
import hashlib
import time
import re
import json
import base64
import urllib
import threading
from bs4 import BeautifulSoup
from utils import get_image_path
import xbmcaddon

_ADDON = xbmcaddon.Addon()

base_params = {
    'pcode': '010110005',
    'version': '2.0.5',
    'devid': hashlib.md5(str(time.time()).encode()).hexdigest(),
    'sys': 'android',
    'sysver': 11,
    'brand': 'google',
    'model': 'Pixel_3_XL',
    'package': 'com.sevenVideo.app.android'
}

base_headers = {
    'User-Agent': 'okhttp/3.12.0',
}


class Spideryingshi(Spider):

    def name(self):
        return '影视'

    def logo(self):
        return get_image_path('yingshi.png')

    def hide(self):
        return not _ADDON.getSettingBool('data_source_yingshi_switch')

    def is_searchable(self):
        return True

    def list_items(self, parent_item=None, page=1):

        if parent_item is None:
            items = []
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='1',
                    name='电影',
                    params={
                        'type': 'category',
                        'pf': 'lz'
                    },
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='2',
                    name='剧集',
                    params={
                        'type': 'category',
                        'pf': 'lz'
                    },
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='4',
                    name='动漫',
                    params={
                        'type': 'category',
                        'pf': 'lz'
                    },
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='3',
                    name='综艺',
                    params={
                        'type': 'category',
                        'pf': 'lz'
                    },
                ))
            return items, False
        elif parent_item['params']['type'] == 'category':
            items = []
            st = time.time()
            url = 'http://lzizy.net/index.php/vod/type/id/{}.html'.format(parent_item['id'])
            header = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36",
                "Referer": url
            }
            r = requests.get(url, headers=header)
            soup = BeautifulSoup(r.text, 'html.parser')
            data = soup.select('ul.videoContent > li')
            maxpage = int(soup.select('div.pages > span.disabled')[0].get_text().split('/')[-1][:-1])
            for video in data:
                vid = re.search(r'/id/(.*?).html', video.select('a')[0].get('href')).group(1).strip()
                remark = video.select('a.videoName > i')[0].get_text().strip()
                name = video.select('a.videoName')[0].get_text().replace(remark, '').strip()
                items.append(
                    SpiderItem(
                        type=SpiderItemType.Directory,
                        name='{0}/[{1}]'.format(name,remark),
                        id=vid,
                        params={
                            'type': 'video',
                            'pf': 'lz'
                        },
                    ))
            if page < maxpage:
                has_next_page = True
            else:
                has_next_page = False
            return items, has_next_page
        elif parent_item['params']['type'] == 'video':
            if parent_item['params']['pf'] == 'qq':
                ts = int(time.time())
                params = base_params.copy()
                params['ids'] = parent_item['id']
                params['sj'] = ts
                headers = base_headers.copy()
                headers['t'] = str(ts)
                url = 'http://api.kunyu77.com/api.php/provide/videoDetail'
                headers['TK'] = self._get_tk(url, params, ts)
                r = requests.get(url, params=params, headers=headers)
                detail = r.json()['data']
                url = 'http://api.kunyu77.com/api.php/provide/videoPlaylist'
                headers['TK'] = self._get_tk(url, params, ts)
                r = requests.get(url, params=params, headers=headers)
                episodes = r.json()['data']['episodes']
                items = []
                for episode in episodes:
                    sources = []
                    danmakus = []
                    for playurl in episode['playurls']:
                        sources.append(
                            SpiderSource(
                                playurl['playfrom'],
                                {
                                    'playfrom': playurl['playfrom'],
                                    'url': playurl['playurl'],
                                    'pf': 'qq'
                                },
                            ))

                        if playurl['playfrom'] in [
                            'qq', 'mgtv', 'qiyi', 'youku', 'bilibili'
                        ]:
                            danmakus.append(
                                SpiderDanmaku(
                                    playurl['playfrom'],
                                    get_danmaku_url(playurl['playurl']),
                                )
                            )
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.File,
                            name=episode['title'].strip(),
                            cover=detail['videoCover'],
                            description=detail['brief'].replace('\u3000', '').replace('<p>', '').replace('</p>','').strip(),
                            cast=detail['actor'].replace(' ', '').split('/'),
                            director=detail['director'],
                            area=detail['area'].strip(),
                            year=int(detail['year'].strip()),
                            sources=sources,
                            danmakus=danmakus,
                        ))
                return items, False
            if parent_item['params']['pf'] == 'lz':
                items = []
                url = 'http://lzizy.net/index.php/vod/detail/id/{}.html'.format(parent_item['id'])
                header = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36",
                    "Referer": url
                }
                r = requests.get(url, headers=header)
                soup = BeautifulSoup(r.text, 'html.parser')
                cover = soup.select('div.left > img')[0].get('src')
                desc = soup.select('div.vod_content > p')[0].get_text().strip().replace('\u3000\u3000', '\n')
                infos = soup.select('div.right > p')
                for info in infos:
                    content = info.get_text()
                    if content.startswith('导演'):
                        dire = content.strip()[3:]
                    if content.startswith('演员'):
                        cast = content.strip()[3:].split(',')
                    if content.startswith('地区'):
                        area = content.strip()[3:]
                    if content.startswith('年代'):
                        year = content.strip()[3:]
                episodes = soup.select('div.playlist.wbox.lzm3u8 > li')[:-1]
                for episode in episodes:
                    sources = []
                    purl = episode.select('a')[0].get('href')
                    sources.append(
                        SpiderSource(
                            'M3U8',
                            {
                                'playfrom': '',
                                'pf': 'lz',
                                'url': purl,
                            },
                        ))

                    name = episode.select('a')[0].get('title').strip()
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.File,
                            name=name,
                            cover=cover,
                            description=desc,
                            cast=cast,
                            director=dire,
                            area=area,
                            year=int(year),
                            sources=sources,
                        ))
                return items, False
            if parent_item['params']['pf'] == 'ik':
                items = []
                header = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
                }
                url = 'https://ikan6.vip/voddetail/{0}/'.format(parent_item['id'])
                r = requests.get(url, headers=header)
                soup = BeautifulSoup(r.text, 'html.parser')
                cover = parent_item['cover']
                infos = soup.select('div.myui-content__detail > p.data')
                yainfo = infos[0].get_text().replace('\n\n', '\n').replace('\t', '').strip('\n').split('\n')
                year = int(yainfo[2].replace('年份：', ''))
                area = yainfo[1].replace('地区：', '')
                cast = infos[2].get_text().replace('主演：', '').strip('\xa0').split('\xa0')
                dire = infos[3].get_text().replace('导演：', '').strip('\xa0')
                desc = soup.select('div.col-pd.text-collapse.content > span.data')[0].get_text().replace('\n', '').replace('\u3000', '').replace('：', '').replace('详情', '').replace('\xa0', '').replace(' ', '')
                p1episodes = []
                p2episodes = []
                if 'id="playlist1"' in r.text:
                    p1episodes = soup.select('div#playlist1> ul')[0].select('li')
                if 'id="playlist2"' in r.text:
                    p2episodes = soup.select('div#playlist2> ul')[0].select('li')
                nump1 = len(p1episodes)
                nump2 = len(p2episodes)
                if nump1 < nump2:
                    episodes = p2episodes
                    main = '爱看(备用)'
                else:
                    episodes = p1episodes
                    main = '爱看(推荐)'
                i = 0
                for episode in episodes:
                    sources = []
                    if main == '爱看(备用)':
                        title = '爱看(备用)'
                        purl = re.search(r'/vodplay/(.*?)/', episode.select('a')[0].get('href')).group(1)
                        sources.append(
                            SpiderSource(
                                title,
                                {
                                    'playfrom': '',
                                    'pf': 'ik',
                                    'url': purl,
                                },
                            ))
                        if i < nump1:
                            title = '爱看(推荐)'
                            purl = re.search(r'/vodplay/(.*?)/', p1episodes[i].select('a')[0].get('href')).group(1)
                            sources.append(
                                SpiderSource(
                                    title,
                                    {
                                        'playfrom': '',
                                        'pf': 'ik',
                                        'url': purl,
                                    },
                                ))
                    else:
                        title = '爱看(推荐)'
                        purl = re.search(r'/vodplay/(.*?)/', episode.select('a')[0].get('href')).group(1)
                        sources.append(
                            SpiderSource(
                                title,
                                {
                                    'playfrom': '',
                                    'pf': 'ik',
                                    'url': purl,
                                },
                            ))
                        if i < nump2:
                            title = '爱看(备用)'
                            purl = re.search(r'/vodplay/(.*?)/', p2episodes[i].select('a')[0].get('href')).group(1)
                            sources.append(
                                SpiderSource(
                                    title,
                                    {
                                        'playfrom': '',
                                        'pf': 'ik',
                                        'url': purl,
                                    },
                                ))
                    i = i + 1
                    name = episode.select('a')[0].get_text().strip()
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.File,
                            name=name,
                            cover=cover,
                            description=desc,
                            cast=cast,
                            director=dire,
                            area=area,
                            year=year,
                            sources=sources
                        ))
                return items, False
        else:
            return [], False


    def resolve_play_url(self, source_params):
        purl = ''
        if source_params['pf'] == 'qq':
            url = source_params['url']
            headers = {}
            if source_params['playfrom'] != 'ppayun':
                jxurl = _ADDON.getSettingString('aliyundrive_refresh_token')
                # jxurl = 'https://raw.iqiq.io/lm317379829/PyramidStore/pyramid/YSDQ.json'
                r = requests.get(jxurl)
                data = r.json()
                if 'QiQi' in data:
                    jxinfos = data['QiQi']
                    for jxinfo in jxinfos:
                        jx = jxinfo['jx']
                        jxfrom = jxinfo['jxfrom']
                        gs = jxinfo['gs'].strip().split(',')
                        erro = jxinfo['erro']
                        jurl = jx + url
                        r = requests.get(jurl)
                        if erro in r.text and erro != '':
                            break
                        url = r.json()
                        for i in range(0, len(gs)):
                            url = url[gs[i]]
                        if url == '':
                            break
                        if jxfrom == 'QiQi':
                            return SpiderPlayURL(
                                get_proxy_url(
                                    Spideryingshi.__name__,
                                    self.proxy_m3u8.__name__,
                                    {
                                        'url': url,
                                        'headers': headers,
                                    },
                                ))
                        else:
                            return SpiderPlayURL(url)
                else:
                    url = ''
                    return SpiderPlayURL(url)
            else:
                return SpiderPlayURL(
                    get_proxy_url(
                        Spideryingshi.__name__,
                        self.proxy_m3u8.__name__,
                        {
                            'url': url,
                            'headers': headers,
                        },
                    ))
        if source_params['pf'] == 'ik':
            header = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36",
                "Referer": "https://ikan6.vip/"
            }
            url = 'https://ikan6.vip/vodplay/{0}/'.format(source_params['url'])
            r = requests.get(url, headers=header)
            cookie = r.cookies
            info = json.loads(re.search(r'var player_data=(.*?)</script>', r.text).group(1))
            string = info['url'][8:len(info['url'])]
            substr = base64.b64decode(string).decode('UTF-8')
            str = substr[8:len(substr) - 8]
            if 'Ali' in info['from']:
                url = 'https://cms.ikan6.vip/ali/nidasicaibudaowozaina/nicaibudaowozaina.php?url={0}'.format(str)
            else:
                url = 'https://cms.ikan6.vip/nidasicaibudaowozaina/nicaibudaowozaina.php?url={0}'.format(str)
            r = requests.get(url, headers=header, cookies=cookie)
            randomurl = re.search(r"getrandom\(\'(.*?)\'", r.text).group(1)
            pstring = randomurl[8:len(randomurl)]
            psubstr = base64.b64decode(pstring).decode('UTF-8')
            purl = urllib.parse.unquote(psubstr[8:len(psubstr) - 8])
            pheader = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
            }
            return SpiderPlayURL(get_proxy_url(Spideryingshi.__name__, self.proxy_m3u8.__name__, {'url': purl, 'headers': pheader}))
        if source_params['pf'] == 'lz':
            purl = source_params['url']
            return SpiderPlayURL(purl)
        return SpiderPlayURL(purl)

    def search(self, keyword):
        sws = ['七七', '爱看', '量子']
        tobj = []
        for sw in sws:
            if sw == '七七':
                ps = threading.Thread(target=self.searchqq, args=(keyword,))
                ps.start()
                tobj.append(ps)
            if sw == '爱看':
                ys = threading.Thread(target=self.searchik, args=(keyword,))
                ys.start()
                tobj.append(ys)
            if sw == '量子':
                zzy = threading.Thread(target=self.searchlz, args=(keyword,))
                zzy.start()
                tobj.append(zzy)
        for t in tobj:
            t.join()
        items = self.qqitems + self.ikitems + self.lzitems
        return items

    def searchqq(self, keyword):
        url = 'http://api.kunyu77.com/api.php/provide/searchVideo'
        ts = int(time.time())
        params = base_params.copy()
        params['sj'] = ts
        params['searchName'] = keyword
        params['pg'] = 1
        headers = base_headers.copy()
        headers['t'] = str(ts)
        headers['TK'] = self._get_tk(url, params, ts)
        r = requests.get(url, params=params, headers=headers)
        data = r.json()
        qqitems = []
        for video in data['data']:
            remark = video['msg'].strip()
            if remark == '':
                remark = 'HD'
            qqitems.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    name='七七：[{0}]/{1}'.format(remark.strip(), video['videoName'].strip()),
                    id=video['id'],
                    cover=video['videoCover'],
                    description=video['brief'],
                    cast=video['starName'].replace(' ','').split(','),
                    year=int(video['year']),
                    params={
                        'type': 'video',
                        'pf': 'qq'
                    },
                ))
        self.qqitems = qqitems

    def searchik(self, keyword):
        url = 'https://ikan6.vip/vodsearch/-------------/?wd={0}&submit='.format(keyword)
        session = self.verifyCode()
        r = session.get(url)
        soup = BeautifulSoup(r.text, 'html.parser')
        data = soup.select('ul#searchList > li')
        ikitems = []
        for video in data:
            sid = re.search(r'/voddetail/(.*?)/', video.find('a').get('href')).group(1)
            name = video.find('h4').get_text().strip()
            year = int(video.select('div.detail > p')[2].get_text().split('年份：')[1])
            description = video.select('div.detail > p')[3].get_text().replace('简介：', '').replace('详情 >', '')
            cover = video.select('div.thumb > a')[0].get('data-original')
            remark = video.select('div.thumb > a')[0].get_text().split('\n')[-1].strip()
            ikitems.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    name='爱看：[{0}]/{1}'.format(remark, name),
                    id=sid,
                    cover=cover,
                    description=description,
                    year=int(year),
                    params={
                        'type': 'video',
                        'pf': 'ik'
                    },
                ))
        self.ikitems =ikitems

    def searchlz(self, keyword):
        lzitems = []
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36",
            "Referer": 'http://lzizy.net/'
        }
        url = 'http://lzizy.net/index.php/vod/search.html?wd={}'.format(keyword)
        r = requests.get(url,headers=header)
        soup = BeautifulSoup(r.text, 'html.parser')
        data = soup.select('ul.videoContent > li')
        for video in data:
            sid = re.search(r'/id/(.*?).html', video.select('a.videoName')[0].get('href')).group(1)
            remark = video.select('a.videoName > i')[0].get_text().strip()
            name = video.select('a.videoName')[0].get_text().replace(remark, '').strip()
            lzitems.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    name='量子：[{0}]/{1}'.format(remark, name),
                    id=sid,
                    params={
                        'type': 'video',
                        'pf': 'lz'
                    },
                ))
        self.lzitems = lzitems

    def verifyCode(self):
        retry = 10
        header = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36"}
        while retry:
            try:
                session = requests.session()
                img = session.get('https://ikan6.vip/index.php/verify/index.html?', headers=header).content
                code = session.post('https://api.nn.ci/ocr/b64/text', data=base64.b64encode(img).decode()).text
                res = session.post(url=f"https://ikan6.vip/index.php/ajax/verify_check?type=search&verify={code}", headers=header).json()
                if res["msg"] == "ok":
                    return session
            except Exception as e:
                print(e)
            finally:
                retry = retry - 1

    def _get_tk(self, url, params, ts):
        keys = []
        for key in params:
            keys.append(key)
        keys.sort()
        src = urlparse(url).path
        for key in keys:
            src += str(params[key])
        src += str(ts)
        src += 'XSpeUFjJ'
        return hashlib.md5(src.encode()).hexdigest()

    def proxy_m3u8(self, ctx, params):
        url = params['url']
        headers = params['headers'].copy()
        r = requests.get(url, headers=headers, stream=True, verify=False)
        content_type = r.headers['Content-Type'] if 'Content-Type' in r.headers else ''
        if content_type.startswith('image/') or content_type.startswith('text/'):
            content_type = 'application/vnd.apple.mpegurl'
        r.headers['Content-Type'] = content_type
        try:
            ctx.send_response(r.status_code)
            for key in r.headers:
                if key.lower() in ['connection', 'transfer-encoding']:
                    continue
                if content_type.lower() == 'application/vnd.apple.mpegurl':
                    if key.lower() in ['content-length', 'content-range']:
                        continue
                ctx.send_header(key, r.headers[key])
            ctx.end_headers()
            if content_type.lower() == 'application/vnd.apple.mpegurl':
                for line in r.iter_lines(8192):
                    line = line.decode()
                    if len(line) > 0 and not line.startswith('#'):
                        if not line.startswith('http'):
                            if line.startswith('/'):
                                line = url[:url.index('/', 8)] + line
                            else:
                                line = url[:url.rindex('/') + 1] + line
                        line = get_proxy_url(
                            Spideryingshi.__name__,
                            self.proxy_ts.__name__,
                            {
                                'url': line,
                                'headers': params['headers'],
                            },
                        )
                    ctx.wfile.write((line + '\n').encode())
            else:
                for chunk in r.iter_content(8192):
                    ctx.wfile.write(chunk)
        except Exception as e:
            print(e)
        finally:
            try:
                r.close()
            except:
                pass

    def proxy_ts(self, ctx, params):
        url = params['url']
        headers = params['headers'].copy()
        for key in ctx.headers:
            if key.lower() in ['user-agent', 'host']:
                continue
            headers[key] = ctx.headers[key]
        r = requests.get(url, headers=headers, stream=True, verify=False)
        r.headers['Content-Type'] = 'video/MP2T'

        try:
            ctx.send_response(r.status_code)
            for key in r.headers:
                if key.lower() in ['connection', 'transfer-encoding', 'accept-ranges']:
                    continue
                ctx.send_header(key, r.headers[key])
            ctx.end_headers()
            stripped_image_header = False
            for chunk in r.iter_content(8192):
                if not stripped_image_header:
                    chunk = chunk.lstrip(b'\x89\x50\x4E\x47\x0D\x0A\x1A\x0A')
                    chunk = chunk.lstrip(b'\x42\x4D\x5A\x27\x4C')
                    chunk = chunk.lstrip(b'\x42\x4D')
                    stripped_image_header = True
                ctx.wfile.write(chunk)
        except Exception as e:
            print(e)
        finally:
            try:
                r.close()
            except:
                pass

#if __name__ == '__main__':
    #spider = Spideryingshi()
    #res = spider.list_items(parent_item={'type': 'directory', 'id': '2', 'name': '剧集', 'cover': '', 'description': '', 'cast': [], 'director': '', 'area': '', 'year': 0, 'sources': [], 'danmakus': [], 'subtitles': [], 'params': {'type': 'category', 'pf': 'lz'}}, page=1)
    #res = spider.resolve_play_url({'playfrom': '', 'pf': 'ik', 'url': '1802-1-1'})
    #res = spider.search("奔跑吧")
    #print(res)