from spider_aliyundrive import SpiderAliyunDrive
from spider import SpiderItemType, SpiderItem
from utils import get_image_path
import requests
import xbmcaddon

_ADDON = xbmcaddon.Addon()


class SpiderYiSou(SpiderAliyunDrive):

    def name(self):
        return '易搜'

    def logo(self):
        return get_image_path('yisou.png')

    def is_searchable(self):
        return True

    def hide(self):
        return not _ADDON.getSettingBool('data_source_yisou_switch')

    def list_items(self, parent_item=None, page=1):
        if parent_item is None:
            return [], False
        else:
            return super().list_items(parent_item, page)

    def search(self, keyword):
        header = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 12; V2049A Build/SP1A.210812.003; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.129 Mobile Safari/537.36",
            "Referer": "https://yiso.fun/"
        }
        url = "https://yiso.fun/api/search?name={0}&from=ali".format(keyword)
        elements = requests.get(url=url, headers=header).json()["data"]["list"]

        items = []
        for element in elements:
            id = element["url"]
            name = element["fileInfos"][0]["fileName"]
            remark = element['gmtCreate'].split(' ')[0]
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id=id,
                    name='[{0}]/{1}'.format(remark, name),
                ))
        return items
