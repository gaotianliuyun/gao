from spider import Spider, SpiderItemType, SpiderSource, SpiderItem, SpiderPlayURL
import requests
import re
import json
import base64
from proxy import get_proxy_url
from utils import get_image_path
from bs4 import BeautifulSoup
import xbmcaddon

_ADDON = xbmcaddon.Addon()

class Spiderikan(Spider):

    def name(self):
        return '爱看'

    def logo(self):
        return get_image_path('ikan.png')

    def is_searchable(self):
        return True

    def hide(self):
        return not _ADDON.getSettingBool('data_source_ikan_switch')

    def list_items(self, parent_item=None, page=1):
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"}
        if parent_item is None:
            items = []
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='1',
                    name='电影',
                    params={
                        'type': 'category',
                    },
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='2',
                    name='剧集',
                    params={
                        'type': 'category',
                    },
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id="3",
                    name='综艺',
                    params={
                        'type': 'category',
                    },
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id="4",
                    name='动漫',
                    params={
                        'type': 'category',
                    },
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id="16",
                    name='美剧',
                    params={
                        'type': 'category',
                    },
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id="15",
                    name='日韩剧',
                    params={
                        'type': 'category',
                    },
                ))
            return items, False

        elif parent_item['params']['type'] == 'category':
            url = 'https://ikan6.vip/vodtype/{0}-{1}/'.format(parent_item['id'], page)
            r = requests.get(url=url, headers=header)
            soup = BeautifulSoup(r.text, 'html.parser')
            data = soup.select('ul.myui-vodlist.clearfix > li')
            items = []
            for video in data:
                vid = re.search(r'/voddetail/(.*?)/', video.select('div.myui-vodlist__box > a')[0].get('href')).group(1)
                name = video.select('div.myui-vodlist__box > a')[0].get('title')
                remark = video.select('span.pic-text.text-right')[0].get_text()
                cover = video.select('div.myui-vodlist__box > a')[0].get('data-original')
                items.append(
                    SpiderItem(
                        type=SpiderItemType.Directory,
                        name='{0}/[{1}]'.format(name,remark),
                        id=vid,
                        cover=cover,
                        params={
                            'type': 'video',
                        },
                    ))
            maxpage = int(soup.select('a.btn.btn-warm')[-1].get_text().split('/')[-1])
            if page < maxpage:
                has_next_page = True
            else:
                has_next_page = False
            return items, has_next_page

        elif parent_item['params']['type'] == 'video':
            url = 'https://ikan6.vip/voddetail/{0}/'.format(parent_item['id'])
            r = requests.get(url, headers=header)
            soup = BeautifulSoup(r.text, 'html.parser')
            cover = parent_item['cover']
            infos = soup.select('div.myui-content__detail > p.data')
            yainfo = infos[0].get_text().replace('\n\n','\n').replace('\t','').strip('\n').split('\n')
            year = int(yainfo[2].replace('年份：',''))
            area = yainfo[1].replace('地区：','')
            cast = infos[2].get_text().replace('主演：','').strip('\xa0').split('\xa0')
            director = infos[3].get_text().replace('导演：','').strip('\xa0')
            description =soup.select('div.col-pd.text-collapse.content > span.data > p')[0].get_text().replace('\n','').replace('\u3000','').replace('：','').replace('详情','').replace('\xa0','').replace(' ','')
            urls = soup.select('ul.myui-content__list.scrollbar.sort-list.clearfix > li')
            items = []
            for url in urls:
                name = url.select('a')[0].get_text()
                id = re.search(r'/vodplay/(.*?)/', url.select('a')[0].get('href')).group(1)
                items.append(
                    SpiderItem(
                        type=SpiderItemType.File,
                        name=name,
                        cover=cover,
                        description=description,
                        cast=cast,
                        director=director,
                        area=area,
                        year=year,
                        sources=[
                            SpiderSource(
                                'ikan',
                                {
                                    'id': id,
                                },
                            )
                        ],
                    ))
            return items, False
        else:
            return [], False

    def resolve_play_url(self, source_params):
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"}
        url = 'https://ikan6.vip/vodplay/{0}/'.format(source_params['id'])
        r = requests.get(url, headers=header)
        info = json.loads(re.search(r'var player_data=(.*?)</script>', r.text).group(1))
        if info['encrypt'] == 1:
            str = info['url'].replace('%u', '\\u').encode('utf-8').decode('unicode_escape')
        elif info['encrypt'] == 2:
            str = base64.b64decode(info['url'].replace('%u', '\\u').encode('utf-8').decode('unicode_escape')).decode('UTF-8')
        elif info['encrypt'] == 3:
            string = info['url'][8:len(info['url'])]
            substr = base64.b64decode(string).decode('UTF-8')
            str = substr[8:len(substr) - 8].split('_')[-1]
        purl = 'https://weiyunsha.ikan6.vip/tsjmjson/play.php?sign={0}'.format(str)
        return SpiderPlayURL(get_proxy_url(Spiderikan.__name__,self.proxy_m3u8.__name__,{'url': purl,'headers': header,},))

    def verifyCode(self):
        retry = 10
        header = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36"}
        while retry:
            try:
                session = requests.session()
                img = session.get('https://ikan6.vip/index.php/verify/index.html?', headers=header).content
                code = session.post('https://api.nn.ci/ocr/b64/text', data=base64.b64encode(img).decode()).text
                res = session.post(url=f"https://ikan6.vip/index.php/ajax/verify_check?type=search&verify={code}",headers=header).json()
                if res["msg"] == "ok":
                    return session
            except Exception as e:
                print(e)
            finally:
                retry = retry - 1

    def search(self, keyword):
        url = 'https://ikan6.vip/vodsearch/-------------/?wd={0}&submit='.format(keyword)
        session = self.verifyCode()
        r = session.get(url)
        soup = BeautifulSoup(r.text, 'html.parser')
        data = soup.select('ul#searchList > li')
        items = []
        for video in data:
            sid = re.search(r'/voddetail/(.*?)/', video.find('a').get('href')).group(1)
            name = video.find('h4').get_text()
            year = int(video.select('div.detail > p')[2].get_text().split('年份：')[1])
            description = video.select('div.detail > p')[3].get_text().replace('简介：','').replace('详情 >','')
            cover = video.select('div.thumb > a')[0].get('data-original')
            remark = video.select('div.thumb > a')[0].get_text().split('\n')[-1]
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    name=name + '/' + remark,
                    id=sid,
                    cover=cover,
                    description=description,
                    year=int(year),
                    params={
                        'type': 'video',
                    },
                ))
        return items

    def proxy_m3u8(self, ctx, params):
        url = params['url']
        headers = params['headers'].copy()
        r = requests.get(url, headers=headers, stream=True, verify=False)
        content_type = r.headers['Content-Type'] if 'Content-Type' in r.headers else ''
        if content_type.startswith('image/') or content_type.startswith('text/'):
            content_type = 'application/vnd.apple.mpegurl'
        r.headers['Content-Type'] = content_type

        try:
            ctx.send_response(r.status_code)
            for key in r.headers:
                if key.lower() in [
                    'connection',
                    'transfer-encoding',
                ]:
                    continue
                if content_type.lower() == 'application/vnd.apple.mpegurl':
                    if key.lower() in [
                        'content-length',
                        'content-range',
                    ]:
                        continue
                ctx.send_header(key, r.headers[key])
            ctx.end_headers()

            if content_type.lower() == 'application/vnd.apple.mpegurl':
                for line in r.iter_lines(8192):
                    line = line.decode()
                    if len(line) > 0 and not line.startswith('#'):
                        if not line.startswith('http'):
                            if line.startswith('/'):
                                line = url[:url.index('/', 8)] + line
                            else:
                                line = url[:url.rindex('/') + 1] + line
                        line = get_proxy_url(
                            Spiderikan.__name__,
                            self.proxy_ts.__name__,
                            {
                                'url': line,
                                'headers': params['headers'],
                            },
                        )
                    ctx.wfile.write((line + '\n').encode())
            else:
                for chunk in r.iter_content(8192):
                    ctx.wfile.write(chunk)
        except Exception as e:
            print(e)
        finally:
            try:
                r.close()
            except:
                pass

    def proxy_ts(self, ctx, params):
        url = params['url']
        headers = params['headers'].copy()
        for key in ctx.headers:
            if key.lower() in [
                'user-agent',
                'host',
            ]:
                continue
            headers[key] = ctx.headers[key]
        r = requests.get(url, headers=headers, stream=True, verify=False)
        r.headers['Content-Type'] = 'video/MP2T'

        try:
            ctx.send_response(r.status_code)
            for key in r.headers:
                if key.lower() in [
                    'connection',
                    'transfer-encoding',
                ]:
                    continue
                ctx.send_header(key, r.headers[key])
            ctx.end_headers()

            stripped_image_header = False
            for chunk in r.iter_content(8192):
                if not stripped_image_header:
                    chunk = chunk.lstrip(b'\x42\x4D\x5A\x27\x4C')
                    chunk = chunk.lstrip(b'\x42\x4D')
                    chunk = chunk.lstrip(b'\x89\x50\x4E\x47\x0D\x0A\x1A\x0A')
                    stripped_image_header = True
                ctx.wfile.write(chunk)
        except Exception as e:
            print(e)
        finally:
            try:
                r.close()
            except:
                pass

#if __name__ == '__main__':
    #spider = Spiderikan()
    #res = spider.list_items(parent_item={'type': 'directory', 'id': '122', 'name': '死囚乐园/[12集全]', 'cover': 'https://p6-bk.byteimg.com/tos-cn-i-mlhdmxsy5m/d63cf73d74cb4024bb7e844d5e076066~tplv-mlhdmxsy5m-q75:0:0.image', 'description': '', 'cast': [], 'director': '', 'area': '', 'year': 0, 'sources': [], 'danmakus': [], 'subtitles': [], 'params': {'type': 'video'}}, page=1)
    #res = spider.resolve_play_url({'id':'2918-1-1'})
    #res = spider.search("同学两亿岁")
    #print(res)