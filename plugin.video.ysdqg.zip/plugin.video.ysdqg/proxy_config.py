class ProxyConfig(object):
    HOST = "127.0.0.1"
    PORT = 59089