from spider import Spider, SpiderItemType, SpiderItem, SpiderSubtitle, SpiderSource, SpiderPlayURL
from utils import get_image_path
import requests
import re
import urllib
import math
import xbmcaddon

_ADDON = xbmcaddon.Addon()

base = {
    'ver': '',
    'baseurl': '',
}

class SpiderAlist(Spider):

    def name(self):
        return 'Alist网盘'

    def logo(self):
        return get_image_path('alist.png')

    def is_searchable(self):
        return False

    def hide(self):
        return not _ADDON.getSettingBool('data_source_alist_switch')

    def list_items(self, parent_item=None, page=1):
        if parent_item is None:
            items = []
            #Alist_or_url = 'https://raw.iqiq.io/lm317379829/PyramidStore/pyramid/YSDQ.json'
            Alist_or_url = _ADDON.getSettingString('aliyundrive_refresh_token')
            if Alist_or_url.startswith('http://') or Alist_or_url.startswith('https://'):
                r = requests.get(Alist_or_url)
                data = r.json()
                if 'Alist' in data:
                    for ids in data['Alist']:
                        name = ids
                        id = data['Alist'][ids]
                        items.append(
                            SpiderItem(
                                type=SpiderItemType.Directory,
                                id=id,
                                name=name,
                                params={
                                    'type': 'category',
                                },
                            ))
            else:
                items.append(
                    SpiderItem(
                        type=SpiderItemType.Directory,
                        id='https://al.chirmyram.com',
                        name='七米蓝',
                        params={
                            'type': 'category',
                        },
                    ))
            return items, False

        elif parent_item['params']['type'] == 'category':
            if parent_item['id'].endswith('/'):
                category_id = parent_item['id']
            else:
                category_id = parent_item['id'] + '/'
            # get ver start
            if base['ver'] == '' or base['baseurl'] == '':
                baseurl = re.findall(r"http.*://.*?/", category_id)[0]
                ver = requests.get(baseurl + 'api/public/settings')
                vjo = ver.json()['data']
                if type(vjo) is dict:
                    ver = 3
                else:
                    ver = 2
                base['ver'] = ver
                base['baseurl'] = baseurl
            else:
                ver = base['ver']
                baseurl = base['baseurl']
                # get ver end
            pat = category_id.replace(baseurl, "")
            param = {
                "path": '/' + pat
            }
            if ver == 2:
                r = requests.post(baseurl + 'api/public/path', json=param)
                data = r.json()['data']['files']
            elif ver == 3:
                r = requests.post(baseurl + 'api/fs/list', json=param)
                data = r.json()['data']['content']
            numdata = len(data)
            times = math.ceil(numdata/60)
            numrey = 0
            numvid =0
            items = []
            subtitles = []
            for a in range(0, times):
                filename = ''
                for i in range(numrey, numdata):
                    video = data[i]
                    if video['type'] == 1:
                        id = category_id + video['name']
                        items.append(
                            SpiderItem(
                                type=SpiderItemType.Directory,
                                name=video['name'],
                                id=id,
                                params={
                                    'type': 'category',
                                },
                            ))
                    else:
                        if ver == 2:
                            pic = video['thumbnail']
                        elif ver == 3:
                            pic = video['thumb']
                        # 计算文件大小 start
                        size = video['size']
                        if size > 1024 * 1024 * 1024 * 1024.0:
                            fs = "TB"
                            sz = round(size / (1024 * 1024 * 1024 * 1024.0), 2)
                        elif size > 1024 * 1024 * 1024.0:
                            fs = "GB"
                            sz = round(size / (1024 * 1024 * 1024.0), 2)
                        elif size > 1024 * 1024.0:
                            fs = "MB"
                            sz = round(size / (1024 * 1024.0), 2)
                        elif size > 1024.0:
                            fs = "KB"
                            sz = round(size / (1024.0), 2)
                        else:
                            fs = "KB"
                            sz = round(size / (1024.0), 2)
                        # 计算文件大小 end
                        remark = str(sz) + fs
                        endits = video['name'].split('.')[-1]
                        if endits in ['mp4', 'mkv', 'ts', 'TS', 'avi', 'flv', 'rmvb', 'mp3', 'flac', 'wav', 'wma','dff']:
                            #filename = filename + '###' + '[{0}]/'.format(remark) + video['name'].replace('\'','{0}{1}'.format('\\','\'')).replace('\"','{0}{1}'.format('\\','\"')) + '___' + pic
                            filename = filename + '###' + '[{0}]/'.format(remark) + video['name'] + '___' + pic
                            numvid = numvid + 1
                        elif endits in ['srt', 'ass', 'vtt']:
                            subname = video['name']
                            #subname = video['name'].replace('\'','{0}{1}'.format('\\','\'')).replace('\"','{0}{1}'.format('\\','\"'))
                            subtitles.append(SpiderSubtitle(subname, 'alist@@@' + category_id + subname))
                    numrey = numrey + 1
                    if numvid % 60 == 0 and numvid !=0:
                        break
                if filename != '':
                    id = category_id + '###' + filename.strip('###')
                    if times == 1:
                        name = category_id.strip('/').split('/')[-1]
                    else:
                        st = int((numvid - 1) / 60) + 1
                        name = category_id.strip('/').split('/')[-1] + '[{0}]'.format(st)
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.Directory,
                            name=name,
                            id=id,
                            subtitles=subtitles,
                            params={
                                'type': 'video',
                            },
                        ))
            has_next_page = False
            return items, has_next_page

        elif parent_item['params']['type'] == 'video':
            ids = parent_item['id'].split('###')
            numids = len(ids)
            url = ids[0]
            data = ids[1:numids]
            items = []
            subtitles = parent_item['subtitles']
            for video in data:
                its = video.split('___')
                cover = its[1]
                itms = its[0].split('/')
                sz = itms[0]
                pf = itms[1]
                #pf = itms[1].replace('{0}{1}'.format('\\','\''),'\'').replace('{0}{1}'.format('\\','\"'),'\"')
                name = sz + '/' + pf
                items.append(
                    SpiderItem(
                        type=SpiderItemType.File,
                        id=pf,
                        name=name,
                        cover=cover,
                        sources=[
                            SpiderSource(
                                'Alist网盘',
                                {
                                    'url': url,
                                    'id': pf,
                                },
                            )
                        ],
                        subtitles=subtitles,
                    ))

            return items, False
        else:
            return [], False

    def resolve_play_url(self, source_params):
        url = source_params['url']
        # get ver start
        if base['ver'] == '' or base['baseurl'] == '':
            baseurl = re.findall(r"http.*://.*?/", url)[0]
            ver = requests.get(baseurl + 'api/public/settings')
            vjo = ver.json()['data']
            if type(vjo) is dict:
                ver = 3
            else:
                ver = 2
            base['ver'] = ver
            base['baseurl'] = baseurl
        else:
            ver = base['ver']
            baseurl = base['baseurl']
            # get ver end
        pf = source_params['id']
        param = {
            "path": '/' + url.replace(baseurl, '') + urllib.parse.unquote(pf)
        }
        if ver == 2:
            r = requests.post(baseurl + 'api/public/path', json=param)
            purl = r.json()['data']['files'][0]['url']
        elif ver == 3:
            r = requests.post(baseurl + 'api/fs/get', json=param)
            purl = r.json()['data']['raw_url']
        if purl.startswith('http') is False:
            head = re.findall(r"h.*?:", baseurl)[0]
            purl = head + purl
        return SpiderPlayURL(purl)

    def resolve_subtitles(self, item):
        url = item.split('@@@')[1]
        # get ver start
        if base['ver'] == '' or base['baseurl'] == '':
            baseurl = re.findall(r"http.*://.*?/", url)[0]
            ver = requests.get(baseurl + 'api/public/settings')
            vjo = ver.json()['data']
            if type(vjo) is dict:
                ver = 3
            else:
                ver = 2
            base['ver'] = ver
            base['baseurl'] = baseurl
        else:
            ver = base['ver']
            baseurl = base['baseurl']
            # get ver end
        param = {
            "path": '/' + url.replace(baseurl, '')
        }
        if ver == 2:
            r = requests.post(baseurl + 'api/public/path', json=param)
            suburl = r.json()['data']['files'][0]['url']
        elif ver == 3:
            r = requests.post(baseurl + 'api/fs/get', json=param)
            suburl = r.json()['data']['raw_url']
        if suburl.startswith('http') is False:
            head = re.findall(r"h.*?:", baseurl)[0]
            suburl = head + suburl
        return suburl


    def search(self, keyword):
        return []

    # if __name__ == '__main__':
        # res = list_items('', parent_item=None, page=1)
        # res = resolve_play_url('', {'id': 'b9a660d384a24b979a49b09395925b21'})
        # res = search('', "真的假的")
        # print(res)