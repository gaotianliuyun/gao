from spider_77 import Spider77
from spider_gitcafe import SpiderGitCafe
from spider_czspp import SpiderCZSPP
from spider_cntv import SpiderCNTV
from spider_bilibili_live import SpiderBiliBiliLive
from spider_douyu_live import SpiderDouYuLive
from spider_qq_live import SpiderQQLive
from spider_alipansou import SpiderAliPanSou
from spider_ikan import Spiderikan
from spider_alist import SpiderAlist
from spider_zhibo import SpiderZhiBo
from spider_zhaoziyuan import SpiderZhaoZiYuan
from spider_kuaibo import SpiderKuaiBo
from spider_aliyundrive import SpiderAliyunDrive
from spider_yisou import SpiderYiSou
from spider_dianshi import SpiderDianShiZhiBo

spiders = {
    Spider77.__name__: Spider77(),
    SpiderKuaiBo.__name__: SpiderKuaiBo(),
    Spiderikan.__name__: Spiderikan(),
    SpiderGitCafe.__name__: SpiderGitCafe(),
    SpiderAlist.__name__: SpiderAlist(),
    SpiderCZSPP.__name__: SpiderCZSPP(),
    SpiderZhiBo.__name__: SpiderZhiBo(),
    SpiderBiliBiliLive.__name__: SpiderBiliBiliLive(),
    SpiderDouYuLive.__name__: SpiderDouYuLive(),
    SpiderQQLive.__name__: SpiderQQLive(),
    SpiderCNTV.__name__: SpiderCNTV(),
    SpiderAliPanSou.__name__: SpiderAliPanSou(),
    SpiderZhaoZiYuan.__name__: SpiderZhaoZiYuan(),
    SpiderAliyunDrive.__name__: SpiderAliyunDrive(),
    SpiderYiSou.__name__: SpiderYiSou(),
    SpiderDianShiZhiBo.__name__: SpiderDianShiZhiBo(),
}
