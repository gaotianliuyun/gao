from spider import SpiderItemType, SpiderItem
from spider_aliyundrive import SpiderAliyunDrive
import re
import threading
import requests
from bs4 import BeautifulSoup
from utils import get_image_path
import xbmcaddon

_ADDON = xbmcaddon.Addon()

class SpiderAli(SpiderAliyunDrive):

    def name(self):
        return '阿里系'

    def logo(self):
        return get_image_path('ali.png')

    def hide(self):
        return not _ADDON.getSettingBool('data_source_ali_switch')

    def is_searchable(self):
        return True

    def list_items(self, parent_item=None, page=1):
        if parent_item is None:
            items = []
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='hydm',
                    name='华语动漫',
                    params={
                        'pf': 'gitcafe',
                    }
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id="hyds",
                    name='华语电视',
                    params={
                        'pf': 'gitcafe',
                    }
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id="hydy",
                    name='华语电影',
                    params={
                        'pf': 'gitcafe',
                    }
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id="omdm",
                    name='欧美动漫',
                    params={
                        'pf': 'gitcafe',
                    }
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id="omds",
                    name='欧美电视',
                    params={
                        'pf': 'gitcafe',
                    }
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id="omdy",
                    name='欧美电影',
                    params={
                        'pf': 'gitcafe',
                    }
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id="rhdm",
                    name='日韩动漫',
                    params={
                        'pf': 'gitcafe',
                    }
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id="rhds",
                    name='日韩电视',
                    params={
                        'pf': 'gitcafe',
                    }
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id="rhdy",
                    name='日韩电影',
                    params={
                        'pf': 'gitcafe',
                    }
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id="qtds",
                    name='其他电视',
                    params={
                        'pf': 'gitcafe',
                    }
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id="qtdy",
                    name='其他电影',
                    params={
                        'pf': 'gitcafe',
                    }
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id="qtsp",
                    name='其他视频',
                    params={
                        'pf': 'gitcafe',
                    }
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id="jlp",
                    name='纪录片',
                    params={
                        'pf': 'gitcafe',
                    }
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id="zyp",
                    name='综艺片',
                    params={
                        'pf': 'gitcafe',
                    }
                ))
            return items, False
        elif not parent_item['id'].startswith('http') and parent_item['params']['pf'] == 'gitcafe':
            r = requests.post('https://gitcafe.net/tool/alipaper/', data={'action': 'viewcat', 'cat': parent_item['id'], 'num': page})
            data = r.json()
            items = []
            for video in data:
                items.append(
                    SpiderItem(
                        type=SpiderItemType.Directory,
                        id='https://www.aliyundrive.com/s/' + video['key'],
                        name=video['title'],
                    ))
            return items, len(items) >= 50
        elif not parent_item['id'].startswith('http') and parent_item['params']['pf'] == 'pansou':
            header = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36',
                 'Referer': 'https://www.alipansou.com' + '/s/' + parent_item['id']
            }
            r = requests.get('https://www.alipansou.com' + '/cv/' + parent_item['id'], allow_redirects=False, headers=header)
            url = re.search(r'href=\"(.*)\"', r.text).group(1)
            parent_item['id'] = url
            return super().list_items(parent_item, page)
        elif not parent_item['id'].startswith('http') and parent_item['params']['pf'] == 'zhaoziyuan':
            regex_url = re.compile(r'https://www.aliyundrive.com/s/[^"]+')
            if len(self.cookies) <= 0:
                self.getCookie()
            r = requests.get('https://zhaoziyuan.la/' + parent_item['id'], cookies=self.cookies)
            m = regex_url.search(r.text)
            url = m.group().replace('\\', '')
            parent_item['id'] = url
            return super().list_items(parent_item, page)
        else:
            return super().list_items(parent_item, page)

    cookies = ''
    def getCookie(self):
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.54 Safari/537.36",
            "Referer": "https://zhaoziyuan.la/login.html",
            "Origin": "https://zhaoziyuan.la/"
        }
        cookie_url = _ADDON.getSettingString('aliyundrive_refresh_token')
        r = requests.get(cookie_url)
        data = r.json()
        if 'Zhaozy' in data:
            logininfo = {'username': data['Zhaozy']['username'], 'password': data['Zhaozy']['password']}
            r = requests.post('https://zhaoziyuan.la/logiu.html', data=logininfo, headers=header)
            self.cookies = r.cookies
            return r.cookies
        return r.cookies

    def searchpansou(self, keyword):
        pitems = []
        r = requests.get('https://www.alipansou.com/search', params={'k': keyword, 't': 7})
        soup = BeautifulSoup(r.text, 'html.parser')
        rows = soup.select('van-row > a')
        for row in rows:
            remark = re.search(r'时间: (.*?) ', str(row.get_text)).group(1)
            clean = re.compile('<.*?>')
            name = re.sub(clean, '', row.find('template').__str__()).replace('\n', '').replace('\t', '').replace(' ', '')
            pitems.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    name='盘搜：[{0}]/{1}'.format(remark, name),
                    id=re.search(r'/s/(.*)', row.get('href')).group(1),
                    params={
                        'pf': 'pansou'
                    }
                ))
        self.pitems = pitems

    def searchyisou(self, keyword):
        yitems = []
        header = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 12; V2049A Build/SP1A.210812.003; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.129 Mobile Safari/537.36",
            "Referer": "https://yiso.fun/"
        }
        url = "https://yiso.fun/api/search?name={0}&from=ali".format(keyword)
        elements = requests.get(url=url, headers=header).json()["data"]["list"]
        for element in elements:
            id = element["url"]
            name = element["fileInfos"][0]["fileName"]
            remark = element['gmtCreate'].split(' ')[0]
            yitems.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id=id,
                    name='易搜：[{0}]/{1}'.format(remark, name),
                    params={
                        'pf': 'yisou'
                    }
                ))
        self.yitems = yitems

    def searchgitcafe(self, keyword):
        gitems = []
        r = requests.post('https://gitcafe.net/tool/alipaper/', data={'action': 'search', 'keyword': keyword})
        data = r.json()
        for video in data:
            gitems.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='https://www.aliyundrive.com/s/' + video['key'],
                    name='小纸条：' + video['title'],
                    params={
                        'pf': 'gitcafe'
                    }
                ))
        self.gitems = gitems

    def searchzhaoziyuan(self, keyword):
        zitems = []
        if len(self.cookies) <= 0:
            self.getCookie()
        r = requests.get('https://zhaoziyuan.la/so', params={'filename': keyword}, cookies=self.cookies)
        soup = BeautifulSoup(r.text, 'html.parser')
        elements = soup.select('div.news_text > a')
        for element in elements:
            name = element.find('h3').text
            if name is None:
                return []
            else:
                remark = element.find('p').text.split('|')[-1].split('：')[1].split(' ')[0].strip()
                zitems.append(
                    SpiderItem(
                        type=SpiderItemType.Directory,
                        id=element.get('href'),
                        name='找资源：[{0}]/{1}'.format(remark, name),
                        params={
                            'pf': 'zhaoziyuan'
                        }
                    ))
        self.zitems = zitems

    def search(self, keyword):
        sws = ['盘搜', '易搜', '找资源', '小纸条']
        tobj = []
        for sw in sws:
            if sw == '盘搜':
                ps = threading.Thread(target=self.searchpansou, args=(keyword,))
                ps.start()
                tobj.append(ps)
            if sw == '易搜':
                ys = threading.Thread(target=self.searchyisou, args=(keyword,))
                ys.start()
                tobj.append(ys)
            if sw == '找资源':
                zzy = threading.Thread(target=self.searchzhaoziyuan, args=(keyword,))
                zzy.start()
                tobj.append(zzy)
            if sw == '小纸条':
                xzt = threading.Thread(target=self.searchgitcafe, args=(keyword,))
                xzt.start()
                tobj.append(xzt)
        for t in tobj:
            t.join()
        items = self.pitems + self.yitems + self.zitems + self.gitems
        return items

#if __name__ == '__main__':
    #spider = SpiderAli()
    #res = spider.list_items(parent_item={'type': 'directory', 'id': 'xsq1LwGcy75nc', 'name': '找资源：[2022-12-31]/H黑暗荣耀【1080P】（2022.韩语中字）全8集', 'cover': '', 'description': '', 'cast': [], 'director': '', 'area': '', 'year': 0, 'sources': [], 'danmakus': [], 'subtitles': [], 'params': {'pf': 'zhaoziyuan'}}, page=1)
    #res = spider.search("黑暗荣耀")
    #res = spider.searchzhaoziyuan("黑暗荣耀")
    #print(res)