from spider_aliyundrive import SpiderAliyunDrive
from spider import SpiderItemType, SpiderItem
from bs4 import BeautifulSoup
from utils import get_image_path
import requests
import re
import xbmcaddon

_ADDON = xbmcaddon.Addon()

class SpiderZhaoZiYuan(SpiderAliyunDrive):

    regex_url = re.compile(r'https://www.aliyundrive.com/s/[^"]+')

    def name(self):
        return '找资源'

    def is_searchable(self):
        return True

    def logo(self):
        return get_image_path('zhaoziyuan.png')

    def hide(self):
        return not _ADDON.getSettingBool('data_source_zhaoziyuan_switch')

    def list_items(self, parent_item=None, page=1):
        if parent_item is None:
            return [], False
        if not parent_item['id'].startswith('http'):
            if len(self.cookies) <= 0:
                self.getCookie()
            r = requests.get('https://zhaoziyuan.la/' + parent_item['id'], cookies=self.cookies)
            m = self.regex_url.search(r.text)
            url = m.group().replace('\\', '')
            parent_item['id'] = url
        return super().list_items(parent_item, page)

    def search(self, keyword):
        if len(self.cookies) <= 0:
            self.getCookie()
        r = requests.get('https://zhaoziyuan.la/so',params={'filename': keyword}, cookies=self.cookies)
        soup = BeautifulSoup(r.text, 'html.parser')
        items = []
        elements = soup.select('div.news_text > a')
        for element in elements:
            name = element.find('h3').text
            if name is None:
                return []
            else:
                remark = element.find('p').text.split('|')[-1].split('：')[1].split(' ')[0].strip()
                items.append(
                    SpiderItem(
                        type=SpiderItemType.Directory,
                        id=element.get('href'),
                        name='[{0}]/{1}'.format(remark, name),
                    ))

        return items

    cookies = ''
    def getCookie(self):
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.54 Safari/537.36",
            "Referer": "https://zhaoziyuan.la/login.html",
            "Origin": "https://zhaoziyuan.la/"
        }
        cookie_url = _ADDON.getSettingString('aliyundrive_refresh_token')
        #cookie_url = 'https://raw.iqiq.io/lm317379829/PyramidStore/pyramid/YSDQ.json'
        r = requests.get(cookie_url)
        data = r.json()
        if 'Zhaozy' in data:
            logininfo = {'username': data['Zhaozy']['username'], 'password': data['Zhaozy']['password']}
            r = requests.post('https://zhaoziyuan.la/logiu.html', data=logininfo, headers=header)
            self.cookies = r.cookies
            return r.cookies
        return r.cookies




#if __name__ == '__main__':
    #spider = SpiderZhaoZiYuan()
    #res = spider.list_items(parent_item={'type': 'directory', 'id': '45674', 'name': '2022世界杯小组赛D组第1轮丹麦VS突尼斯/[HD]', 'cover': '', 'description': '', 'cast': [], 'director': '', 'area': '', 'year': 0, 'sources': [], 'danmakus': [], 'subtitles': [], 'params': {'type': 'video'}}, page=1)
    #res = spider.resolve_play_url({'id': 'https://new.yle888.vip/20221125/Zj2pwaSL/index.m3u8'})
    #res = spider.search("棒球大联盟")
    #print(res)