from spider import Spider, SpiderItemType, SpiderSource, SpiderItem, SpiderPlayURL
import requests
import threading
from bs4 import BeautifulSoup
from utils import get_image_path
import xbmcaddon

_ADDON = xbmcaddon.Addon()

jsonurl = _ADDON.getSettingString('aliyundrive_refresh_token')
if jsonurl.startswith('http'):
    jr = requests.get(jsonurl)
    jdata = jr.json()
else:
    jdata = {}
class SpiderDianShiZhiBo(Spider):

    def name(self):
        return '电视直播'

    def logo(self):
        return get_image_path('dianshi.png')

    def is_searchable(self):
        return False

    def hide(self):
        return not _ADDON.getSettingBool('data_source_dianshi_switch')

    def list_items(self, parent_item=None, page=1):
        header = {
            "User-Agent": "Mozilla/5.0 (Linux; U; Android 9; zh-cn; MIX 2S Build/PKQ1.180729.001) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/61.0.3163.128 Mobile Safari/537.36 XiaoMi/MiuiBrowser/10.1.1"}
        if parent_item is None:
            r = requests.get('http://www.lu1.cc/c/tv/sjtv/index.htm', headers=header)
            soup = BeautifulSoup(r.content.decode('utf-8'), 'html.parser')
            datas = soup.select('ul > li')
            items = []
            for data in datas:
                name = data.get_text().strip()
                id = data.select('a')[0].get('href')
                items.append(
                    SpiderItem(
                        type=SpiderItemType.Directory,
                        name=name,
                        id=id,
                        params={
                            'type': 'category',
                        },
                    ))
            return items, False

        elif parent_item['params']['type'] == 'category':
            url = 'http://www.lu1.cc/c/tv/sjtv/{0}'.format(parent_item['id'])
            r = requests.get(url=url, headers=header)
            soup = BeautifulSoup(r.content.decode('utf-8'), 'html.parser')
            data = soup.select('li')
            items = []
            for video in data:
                vid = video.select('a')
                if vid ==[]:
                    continue
                vid = vid[0].get('href')
                name = video.get_text()
                cover = 'https://i.postimg.cc/QxCn329F/television.png'
                items.append(
                    SpiderItem(
                        type=SpiderItemType.Directory,
                        id=vid,
                        name=name,
                        cover=cover,
                        params={
                            'type': 'video',
                        },
                    ))
            return items, False

        elif parent_item['params']['type'] == 'video':
            url = 'http://www.lu1.cc/c/tv/sjtv/{0}'.format(parent_item['id'])
            r = requests.get(url=url, headers=header)
            soup = BeautifulSoup(r.content.decode('utf-8'), 'html.parser')
            urls = soup.select('option')
            sources = []
            if urls ==[]:
                purl = soup.select('video')
                if purl == []:
                    return [], False
                purl = purl[0].get('src')
                sources.append(
                    SpiderSource(
                        '默认',
                        {
                            'id': purl,
                        },
                    ))
            items = []
            for url in urls:
                purl = url.get('value')
                if purl == '':
                    continue
                title = url.get_text().strip()
                sources.append(
                    SpiderSource(
                        title,
                        {
                            'id': purl,
                        },
                    ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.File,
                    name=parent_item['name'],
                    sources=sources,
                ))
            ckpurlList = []
            for purlDict in items[0]['sources']:
                tag = purlDict['name']
                if not 'm3u' in purlDict['params']['id']:
                    header = {
                        "User-Agent": "Mozilla/5.0 (Linux; U; Android 9; zh-cn; MIX 2S Build/PKQ1.180729.001) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/61.0.3163.128 Mobile Safari/537.36 XiaoMi/MiuiBrowser/10.1.1"}
                    url = purlDict['params']['id']
                    r = requests.get(url=url, allow_redirects=False, headers=header)
                    purl = r.headers['Location']
                else:
                    purl = purlDict['params']['id']
                ckpurl = threading.Thread(target=self.checkpurl, name='ckpurl', args=(purl, tag))
                ckpurl.daemon = True
                ckpurl.start()
                ckpurlList.append(ckpurl)
            for ckL in ckpurlList:
                ckL.join()
            nsources = []
            for ckdL in self.checkList:
                if self.checkList[ckdL].startswith('keep'):
                    purl = self.checkList[ckdL].split('@@@')[-1]
                    nsources = nsources + [{'name': ckdL, 'params': {'id': purl}}]
            if len(nsources) == 0:
                items = []
            else:
                nsources.sort(key=lambda i: (i)['name'], reverse=False)
                items[0]['sources'] = nsources
            return items, False
        else:
            return [], False

    thlimit = 5
    checkList = {}
    def checkpurl(self, url, tag):
        try:
            r = requests.get(url, timeout=1)
            if not r.text.startswith('#EXTM3U'):
                stat = 'del'
            else:
                stat = 'keep@@@' + url
        except requests.exceptions.RequestException:
            stat = 'del'
        self.checkList.update({tag: stat})

    def resolve_play_url(self, source_params):
        return SpiderPlayURL(source_params['id'])

    def search(self, keyword):
        return []

#if __name__ == '__main__':
    #spider = SpiderDianShiZhiBo()
    #res = spider.list_items(parent_item={'type': 'directory', 'id': 'ys/cctv1.htm', 'name': 'CCTV3综艺', 'cover': 'https://i.postimg.cc/QxCn329F/television.png', 'description': '', 'cast': [], 'director': '', 'area': '', 'year': 0, 'sources': [], 'danmakus': [], 'subtitles': [], 'params': {'type': 'video'}}, page=1)
    #res = spider.resolve_play_url({'id': 'http://httpdvb.slave.yqdtv.com:13164/playurl?&programid=4200000124&playtype=live&protocol=hls&accesstoken=G171CCF47V21307D1TE06202J347C03ABM7902F3A5I2A659027K98BDA6&playtoken=.m3u8'})
    #res = spider.search("")
    #print(res)